﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa;


namespace Entidades.Externa
{
    public class EntidadesExternaDerivada : PersonaExterna
    {
        public EntidadesExternaDerivada(string nombre, string apellido, int edad, ESexo sexo)
            : base(nombre,apellido,edad, sexo)
        { }

        public string Nombre { get { return this._nombre; } }
        public string Apellido { get { return this._apellido; } }
        public int Edad { get { return this._edad; } }
        public ESexo Sexo { get { return this._sexo; } }
    }
}
