﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
using System.Runtime;
//using Entidades.Externa.Sellada;
//using Entidades.Externa;

namespace Entidades.Alumnos
{
    public static class Extensora
    {
        public static String ObtenerInfo(this Persona p)
        {
            return (p.Nombre + "-" + p.Apellido + "-" + p.Edad + "-" + p.Sexo);
        }

        public static bool EsNull(this object obj)
        {
            bool retorno = false;

            if (obj == null)
            { retorno = true; }


            return retorno;
        }

        public static Boolean EscribeArchivo(this Persona p, string path)
        {
            bool retorno = false;
            StreamWriter Escribe = new StreamWriter(path);

            if (Escribe != null)
            {
                Escribe.WriteLine(p.ToString());
                retorno = true;
            }
            Escribe.Close();

            return retorno;
        }

        public static int CantidadCaracteres(this String obj)
        {
            return obj.Length;
        }

        public static bool EscribeEnTablas(this Persona obj)
        {
            bool retorno = false;
            SqlConnection Conexion = new SqlConnection(Properties.Settings.Default.Servicios);

            try
            {
                Conexion.Open();

                SqlCommand Comando = new SqlCommand("INSERT into [personasBD].[dbo].[tablaPersonas]([nombre],[apellido],[edad],[sexo]) VALUES ('" + obj.Nombre + "','" + obj.Apellido + "'," + obj.Edad + " , " + ((int)obj.Sexo) + ")", Conexion);

                if (Comando.ExecuteNonQuery() > 0)
                { retorno = true; }
            }
            catch (Exception e)
            { Console.WriteLine(e.Message); }
            finally
            { Conexion.Close(); }

            return retorno;
        }
    }
}
