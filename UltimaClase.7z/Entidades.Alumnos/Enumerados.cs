﻿namespace Entidades.Alumnos
{
    public enum ESexo
    {
        Femenino,
        Masculino,
        Indefinido
    }
}