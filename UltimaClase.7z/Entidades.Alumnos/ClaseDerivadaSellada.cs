﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime;
using System.Data.Sql;
using System.Data.SqlClient;
using Entidades.Alumnos;

namespace Entidades.Externa.Sellada
{
    public static class ClaseDerivadaSellada 
    {
        public static Boolean EscribeArchivo(this PersonaExternaSellada p, string path)
        {
            bool retorno = false;
            StreamWriter Escribe = new StreamWriter(path);

            if (Escribe != null)
            {
                Escribe.WriteLine(p.ToString());
                retorno = true;
            }
            Escribe.Close();

            return retorno;
        }

        public static String ObtenerInfo(this Persona p)
        {
            return (p.Nombre + "-" + p.Apellido + "-" + p.Edad + "-" + p.Sexo);
        }

        public static bool EsNull(this object obj)
        {
            bool retorno = false;

            if (obj == null)
            { retorno = true; }


            return retorno;
        }

        public static int CantidadCaracteres(this String obj)
        {
            return obj.Length;
        }



    }
}
