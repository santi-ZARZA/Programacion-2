﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Alumnos;
using Entidades.Externa;
using Entidades.Externa.Sellada;


namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona perso = new Persona("a", "ab", 1, Entidades.Alumnos.ESexo.Indefinido);

           // Console.WriteLine(perso.ObtenerInfo());


            if (perso.EscribeEnTablas())
            {
                Console.WriteLine("Funciona");
            }
            else
            { Console.WriteLine("No funciona"); }

            //Console.WriteLine("cantidad de caracteres"+(perso.ToString()).CantidadCaracteres());

            Console.ReadLine();

        
        }
    }
}
