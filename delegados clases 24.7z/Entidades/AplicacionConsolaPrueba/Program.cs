﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesDelegados;

namespace AplicacionConsolaPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            Empleado empleado = new Empleado("", "", 0);

            empleado.SueldoCero += new DelegadoSueldoCero(Empleado.ManejadorEmpleado);
            empleado.SueldoLimite += new DelegadoLimiteSueldo(Empleado.ManejadorSueldoLimite);
            empleado.SueldoMejorado += new DelLimiteSueldoMejorado(Empleado.ManejadorSueldoExtendido);
                
              empleado.Sueldo = 1;
            //empleado.Sueldo = 0;
            //empleado.Sueldo = -1;

        }
    }
}
