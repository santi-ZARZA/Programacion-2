﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesDelegados
{
    public delegate void DelegadoSueldoCero();

    public delegate void DelegadoLimiteSueldo(Double x,Empleado m);

    public class SueldoNegativoExcepcion : Exception
    {

    }
}
