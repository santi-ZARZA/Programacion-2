﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesDelegados
{
    public class Empleado
    {
        string _nombre;
        string _apellido;
        int _dni;
        private double _sueldo;

        public Empleado(string nombre, string apellido, int dni)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._dni = dni;
        }

        public double Sueldo
        {
            get
            {
                return this._sueldo;
            }
            set
            {
                if (value < 0)
                {
                    throw new SueldoNegativoExcepcion(); 
                }
                else if (value == 0) 
                { 
                    this.SueldoCero.Invoke();
                }
                else if (value >= 10000) 
                { 
                    this.SueldoLimite.Invoke(value, this);
                }
                else if (value >= 20000 && value <= 30000)
                {
                    EmpleadoEventArgs empleado= new EmpleadoEventArgs();
                    empleado.Sueldo = value;
                    this.SueldoMejorado.Invoke(this,empleado);
                }
                else 
                {
                    this._sueldo = value;
                }
            }
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.AppendFormat("Nombre: {0}", this._nombre);
            stringBuilder.AppendFormat("Apellido: {0}", this._apellido);
            stringBuilder.AppendFormat("Dni: {0}", this._dni);

            return stringBuilder.ToString();
        }


        #region Evento
        public event DelegadoSueldoCero SueldoCero;

        public event DelegadoLimiteSueldo SueldoLimite;

        public event DelLimiteSueldoMejorado SueldoMejorado;
        #endregion

        public static void ManejadorEmpleado()
        {
            Console.WriteLine("Ojo que le estas poniendo sueldo cero al empleado");
            
        }

        public static void ManejadorSueldoLimite(Double sueldoPedido, Empleado EmpleadoX)
        {
            if (sueldoPedido > 10000)
            {
                Console.WriteLine("El sueldo maximo es 10.000");
            }
            else
            {
                Console.WriteLine("Se le aumentara el sueldo");
            }
        }

        public static void ManejadorSueldoExtendido(Empleado sueldoPedido, EmpleadoEventArgs EmpleadoX)
        {
            if(EmpleadoX.Sueldo > 30000)
            {
                Console.WriteLine("El sueldo maximo es 30.000");
            }
            else
            {
                Console.WriteLine("Se le aumentara el sueldo");
            }
        }


    }
}
