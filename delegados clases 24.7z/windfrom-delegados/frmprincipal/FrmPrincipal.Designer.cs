﻿namespace frmprincipal
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnAltas = new System.Windows.Forms.ToolStripMenuItem();
            this.mnTestDelegados = new System.Windows.Forms.ToolStripMenuItem();
            this.mnAlumno = new System.Windows.Forms.ToolStripMenuItem();
            this.mnMostrar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnAltas,
            this.mnMostrar});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(379, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnAltas
            // 
            this.mnAltas.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnTestDelegados,
            this.mnAlumno});
            this.mnAltas.Name = "mnAltas";
            this.mnAltas.Size = new System.Drawing.Size(45, 20);
            this.mnAltas.Text = "Altas";
            // 
            // mnTestDelegados
            // 
            this.mnTestDelegados.Name = "mnTestDelegados";
            this.mnTestDelegados.Size = new System.Drawing.Size(154, 22);
            this.mnTestDelegados.Text = "Test Delegados";
            this.mnTestDelegados.Click += new System.EventHandler(this.mnTestDelegados_Click);
            // 
            // mnAlumno
            // 
            this.mnAlumno.Name = "mnAlumno";
            this.mnAlumno.Size = new System.Drawing.Size(154, 22);
            this.mnAlumno.Text = "Alumno";
            // 
            // mnMostrar
            // 
            this.mnMostrar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.mnMostrar.Name = "mnMostrar";
            this.mnMostrar.Size = new System.Drawing.Size(60, 20);
            this.mnMostrar.Text = "Mostrar";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem5.Text = "toolStripMenuItem5";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem6.Text = "toolStripMenuItem6";
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 323);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmPrincipal";
            this.Text = "frmPrincipal";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnAltas;
        private System.Windows.Forms.ToolStripMenuItem mnMostrar;
        private System.Windows.Forms.ToolStripMenuItem mnTestDelegados;
        private System.Windows.Forms.ToolStripMenuItem mnAlumno;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
    }
}

