﻿public enum EFranja
{
    Franja_1,
    Franja_2,
    Franja_3
}
public enum ETipoLlamada
{
    Local,
    Provincial,
    Todas
}