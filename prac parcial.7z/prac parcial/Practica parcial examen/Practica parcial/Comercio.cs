﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Practica_parcial_Ventas;
using Practica_parcial_Articulos;

namespace Practica_parcial_Comercio
{
    public class Comercio
    {
        protected string _dueño;
        protected List<Articulo> _misarticulos;
        protected List<Venta> _misventas;

        public Comercio(string dueño)
        {
            this._dueño = dueño;
            this._misarticulos = new List<Articulo>();
            this._misventas = new List<Venta>();
        }

        public void ComprarArticulo(Articulo articulocomprado)
        {
            int aux = 0;
            bool bandera = false;
            foreach (Articulo i in this._misarticulos)
            {
                if (i == articulocomprado)
                {
                    aux = i + articulocomprado;
                    this._misarticulos[this._misarticulos.IndexOf(i)].Stock = aux; 
                    bandera = true;
                    break;
                }
            }
            if (bandera == false)
            {
                this._misarticulos.Add(articulocomprado);
            }
        }// ya desarrollada

        public static void MostrarArticulos(Comercio comercioAMostrar)
        {
            string muestra = "";

            foreach (Articulo i in comercioAMostrar._misarticulos)
            {
                muestra += i.NombreYCodigo + "\n";
            }

            Console.WriteLine(muestra);
            Console.ReadKey();

        }// ya desarrollada

        public static void MostrarGanancias(Comercio comerciopararesumen)
        {
//            string muestra = "";
            float sumatotal = 0;

            foreach (Venta i in comerciopararesumen._misventas)
            {
                sumatotal += i.RetornaGanancia();
                //muestra += ().ToString();
            }

  //          muestra = sumatotal.ToString();

            Console.WriteLine("la ganancia obtenida es: {0}",sumatotal);
            Console.ReadKey();

        }// ya desarrollada

        public void VenderArticulo(Articulo articulosolicitado, int cantidad)
        {
            Boolean flagHayArt = false;

            for (int i = 0; i < this._misarticulos.Count; i++)
            {
                if (articulosolicitado == this._misarticulos[i])
                {
                    if (this._misarticulos[i].HayStock(cantidad))
                    {
                        this._misarticulos[i].Stock = this._misarticulos[i] - cantidad;
                        Venta ventaRealizada = new Venta(articulosolicitado, cantidad);
                        this._misventas.Add(ventaRealizada);
                    }
                    else
                    {
                        Console.WriteLine("No hay stock para\n{0}", this._misarticulos[i].NombreYCodigo);
                    }
                    flagHayArt = true;
                    break;
                }
            }

            if (flagHayArt == false)
            { Console.WriteLine("No existe producto \n{0}", articulosolicitado.NombreYCodigo); }

        }// ya desarrollada

    }

}
