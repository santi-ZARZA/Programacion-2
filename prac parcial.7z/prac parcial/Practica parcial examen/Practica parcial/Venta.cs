﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Practica_parcial_Articulos;

namespace Practica_parcial_Ventas
{
    public class Venta
    {
        protected Articulo _articulovendido;
        protected int _cantidad;

        public Venta(Articulo articulovendido, int cantidad)
        {
            this._articulovendido = articulovendido;
            this._cantidad = cantidad;
        }

        public float RetornaGanancia()
        {
            return this._articulovendido.PrecioVenta * this._cantidad;
        }// ya desarrollada
    }

}
