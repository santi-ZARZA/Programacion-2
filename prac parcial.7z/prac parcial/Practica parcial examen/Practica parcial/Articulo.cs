﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_parcial_Articulos
{
    public class Articulo
    {
        protected int _codigo;
        protected int _stock;
        protected string _nombre;
        protected float _preciocosto;
        protected float _precioventa;

        public string NombreYCodigo
        {
            get
            {
                string retorno = "";

                retorno += this._nombre + "--" + this._codigo.ToString();

                return retorno;
            }
        }

        public float PrecioCosto 
        { 
            set 
            {
                float aux = (value*30)/100;
                this._precioventa = value + aux;
                this._preciocosto = value ;
            }
        }

        public float PrecioVenta 
        {
            get
            {
               return this._precioventa;
            }
        }

        public int Stock 
        {
            set
            {
                this._stock = value;
            }
        }

        public Articulo(int codigo,string nombre,float preciocosto,int cantidad)
        {
            this._codigo = codigo;
            this._nombre = nombre;
            this._preciocosto = preciocosto;
            this._stock = cantidad;
        }

        public bool HayStock(int cantidad)
        {
            bool retorno = false;

            if (this._stock >= cantidad)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator ==(Articulo art1, Articulo art2)
        {
            bool retorno = false;

            if (art1._nombre == art2._nombre && art1._codigo == art2._codigo)
            {
                retorno = true;
            }

            return retorno;
        }// ya desarrollada

        public static bool operator !=(Articulo art1, Articulo art2)
        {
            return !(art1 == art2);
        }

        public static int operator +(Articulo art1, Articulo art2)
        {
            return art1._stock + art2._stock;
        }// ya desarrollada

        public static int operator -(Articulo art1, int cantidad)
        {
            int retorno = 0;

            if (art1._stock >= cantidad)
            {
                retorno = art1._stock - cantidad;
            }

            return retorno;
        }// ya desarrollada

    }

    public class ArticuloInternacional
    {
        protected Articulo _articulointernacional;

        public string impuesto()
        { 
            return "";
        }

        public string ParaIngresar()
        {
            return "";
        }


    }

}