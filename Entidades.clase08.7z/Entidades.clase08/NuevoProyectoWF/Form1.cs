﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.clase08;

namespace NuevoProyectoWF
{
    public partial class FRMjugador : Form
    {
        private Jugador jugador;

        public FRMjugador()
        {
            InitializeComponent();
        }

        public Jugador GetJugador()
        {
            return this.jugador;
        }


        private void buttonACEPTAR_Click(object sender, EventArgs e)
        {

            Jugador nuevo = new Jugador(this.textBox_NOMBRE.Text, long.Parse(this.textBox_DNI.Text),int.Parse(this.textBox_PAR_JUGADOS.Text),int.Parse(this.textBoxGOLES.Text));

            MessageBox.Show(nuevo.MostrarDatos());
        }


    }
}
