﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.clase08;

namespace NuevoProyectoWF
{
    public partial class Equipo : Form
    {
        private Equipo equipo;

        public Equipo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.button2.Enabled = false;
            this.button2.Visible = false;
            this.textBox1.Enabled = true;
            this.textBox2.Enabled = true;

            this.listBox1.Visible = true;
            this.button3.Visible = true;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


    }
}
