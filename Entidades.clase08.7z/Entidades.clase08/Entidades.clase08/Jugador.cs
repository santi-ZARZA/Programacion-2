﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.clase08
{
    public class Jugador
    {
        private long dni;
        private string nombre;
        private int partidosjugados;
        private float promedioGoles;
        private int totalgoles;


        private Jugador()
        {
            this.dni = 1;
            this.nombre = "sin nombre";
            this.partidosjugados = 0;
            this.totalgoles = 0;
            this.promedioGoles = 0;
        }

        public Jugador(string nombre,long dni):this()
        {
            this.nombre = nombre;
            this.dni = dni;
        }

        public Jugador(string nombre, long dni, int totalgoles,int totalpartidos):this(nombre,dni)
        {
            this.totalgoles = totalgoles;
            this.partidosjugados = totalpartidos;
        }

        public float getPromedioGoles()
        {
           return this.promedioGoles = (float)this.totalgoles / (float)this.partidosjugados;
        }

        public static Boolean operator ==(Jugador J1, Jugador J2)
        {
            Boolean retorno = false;

            if (J1.dni == J2.dni)
            {
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator !=(Jugador J1, Jugador J2)
        {
            return !(J1 == J2);
        }

        public string MostrarDatos()
        {
            string retorno = "";

            retorno += this.dni + "\n";
            retorno += this.nombre + "\n";
            retorno += this.partidosjugados + "\n";
            retorno += this.totalgoles + "\n";
            retorno += this.promedioGoles + "\n";

            return retorno;
        }
    }
}
