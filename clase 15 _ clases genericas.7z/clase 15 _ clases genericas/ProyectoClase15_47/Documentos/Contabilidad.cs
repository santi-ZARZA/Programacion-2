﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using clase_16_05;

namespace Documentos
{
    public class Contabilidad<T,U>
        where T : Documento
        where U : Documento
        where U : new()
    {
        List<T> Egreso = new List<T>();
        List<U> Ingreso = new List<U>();

        public static Contabilidad<T, U> operator +(Contabilidad<T, U> c, T egreso)
        {

            Contabilidad<T, U> aux = c;
            aux.Egreso.Add(egreso);
            return aux;
        }

        public static Contabilidad<T, U> operator +(Contabilidad<T, U> c, U egreso)
        {
            Contabilidad<T, U> aux = c;
            aux.Ingreso.Add(egreso);
            return aux;
        }
    }
}
