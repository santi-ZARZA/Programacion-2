﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Auto
    {
        private string _marca;
        private string _color;

        public string Color { get { return this._color; } }

        public string Marca { get { return this._marca; } }

        public Auto(string color, string marca)
        {
            this._color = color;
            this._marca = marca;
        }

        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (obj is Auto)
            {
                if (this == ((Auto)obj))
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public override string ToString()
        {
            string retorno ="Color: " + this.Color + " ------- "+ "Marca: " + this.Marca + "\n";
            return retorno;
        }

        public static bool operator ==(Auto A, Auto B)
        {
            bool retorno = false;

            if (A.Color == B.Color && A.Marca == B.Marca)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Auto A, Auto B)
        {
            return !(A == B);
        }
    }

    public class DepositoDeAutos
    {
        private int _capacidadMaxima;

        private List<Auto> _lista;

        public bool Agregar(Auto X)
        {
            return (this + X);
        }

        public DepositoDeAutos(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Auto>();
        }

        private int GetIndice(Auto X)
        {
            return (this._lista.IndexOf(X));
        }

        public static bool operator -(DepositoDeAutos A, Auto B)
        {
            bool retorno = false;
            int AUX = A.GetIndice(B);

            if(AUX != -1)
            {
                A._lista.RemoveAt(AUX);
                retorno = true;
            }

            return retorno;
        }

        public static bool operator +(DepositoDeAutos A, Auto B)
        {
            bool retorno = false;
            if (A._capacidadMaxima > A._lista.Count)
            {
                A._lista.Add(B);
                retorno = true;
            }

            return retorno;
        }

        public bool Remove(Auto X)
        {
            return (this - X);
        }

        public override string ToString()
        {
            string retorno = "Listado de autos:\n";

            foreach (Auto item in this._lista)
            {
                retorno += item.ToString();
            }

            return retorno;
        }

    }

    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _Precio;

        public int Codigo { get { return this._codigo; } }

        public bool EsIndustrial { get { return this._esIndustrial; } }

        public double Precio { get { return this._Precio; } }

        public Cocina(int codigo, bool esindustrial, double precio)
        {
            this._codigo = codigo;
            this._esIndustrial = esindustrial;
            this._Precio = precio;
        }

        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (obj is Cocina)
            {
                if (this._codigo == ((Cocina)obj)._codigo)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator ==(Cocina A, Cocina B)
        {
            bool retorno = false;

            if (A._codigo == B._codigo && A._esIndustrial == B._esIndustrial && A._Precio == B._Precio)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Cocina A, Cocina B)
        {
            return !(A == B);
        }

        public override string ToString()
        {
            string retorno = "Codigo: " + this._codigo + "----" + "Es Industrial: " + this._esIndustrial + "----" + "Precio: " + this._Precio +"\n";
            return retorno;
        }
    }

    public class DepositoDeCocinas
    {
        private int _capacidadMaxima;

        private List<Cocina> _lista;

        public bool Agregar(Cocina X)
        {
            return (this + X);
        }

        public DepositoDeCocinas(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Cocina>();
        }

        private int GetIndice(Cocina X)
        {
            return (this._lista.IndexOf(X));
        }

        public static bool operator -(DepositoDeCocinas A, Cocina B)
        {
            bool retorno = false;
            int AUX = A.GetIndice(B);

            if (AUX != -1)
            {
                A._lista.RemoveAt(AUX);
                retorno = true;
            }

            return retorno;
        }

        public static bool operator +(DepositoDeCocinas A, Cocina B)
        {
            bool retorno = false;
            if (A._capacidadMaxima > A._lista.Count)
            {
                A._lista.Add(B);
                retorno = true;
            }

            return retorno;
        }

        public bool Remove(Cocina X)
        {
            return (this - X);
        }

        public override string ToString()
        {
            string retorno = "Listado de cocinas:\n" + "Capacidad maxima: " + this._capacidadMaxima + "\n";

            foreach (Cocina item in this._lista)
            {
                retorno += item.ToString();
            }

            return retorno;
        }

    }

    public class Deposito<T> 
    {
               
        private int _capacidadMaxima;

        private List<T> _lista;

        public bool Agregar(T X)
        {
            return (this + X);
        }

        public Deposito(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<T>();
        }

        private int GetIndice(T X)
        {
            return (this._lista.IndexOf(X));
        }

        public static bool operator -(Deposito<T> A, T B)
        {
            bool retorno = false;
            int AUX = A.GetIndice(B);

            if (AUX != -1)
            {
                A._lista.RemoveAt(AUX);
                retorno = true;
            }

            return retorno;
        }

        public static bool operator +(Deposito<T> A, T B)
        {
            bool retorno = false;
            if (A._capacidadMaxima > A._lista.Count)
            {
                A._lista.Add(B);
                retorno = true;
            }

            return retorno;
        }

        public bool Remove(T X)
        {
            return (this - X);
        }

        public override string ToString()
        {
            string retorno = "Listado de Depositos:\n"+ "Capacidad maxima: " + this._capacidadMaxima + "\n";

            foreach (T item in this._lista)
            {
                retorno += item.ToString();
            }

            return retorno;
        }
    }


}
