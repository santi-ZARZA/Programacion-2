﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Entidades
{
    public class Persona
    {
        private string _nombre;
        private string _apellido;
        private int _edad;
        private int _id;

        #region Propiedad/es
        public string Nombre
        { 
            get { return this._nombre; }
            set { this._nombre = value; }
        }
        public string Apellido
        {
            get { return this._apellido; }
            set { this._apellido = value; }
        }
        public int Edad
        {
            get { return this._edad; }
            set { this._edad = value; }
        }
        public int Id
        {
            get { return this._id; }
        }
        #endregion

        #region Constructor/es
        public Persona(string nom, string ape, int edad)
        {
            this._apellido = ape;
            this._nombre = nom;
            this._edad = edad;
        }
        public Persona(string nom, string ape, int edad, int id)
        {
            this._apellido = ape;
            this._nombre = nom;
            this._edad = edad;
            this._id = id;
        }
        #endregion

        public static List<Persona> TraerTodos()
        {
            List<Persona> retorna = new List<Persona>();

            SqlConnection Obj_sql_conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            Obj_sql_conexion.Open();

            SqlCommand comando = new SqlCommand("SELECT [id],[nombre],[apellido],[edad] FROM [Padron].[dbo].[Personas]", Obj_sql_conexion);

            SqlDataReader sql = comando.ExecuteReader();

            while (sql.Read())
            {
                retorna.Add(new Persona(sql["nombre"].ToString(),sql["apellido"].ToString(),(int)sql["edad"],(int)sql["id"]));
            }
            sql.Close();
            Obj_sql_conexion.Close();

            return retorna;
        }

        public override string ToString()
        {
            return (this.Nombre + "-" + this.Apellido + "-" + this.Edad + "-" + this.Id );
        }

    }
}
