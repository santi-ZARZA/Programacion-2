﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace ProyectoConsola
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach (Persona item in Persona.TraerTodos())
            {
                Console.WriteLine(item.ToString());
            }

            Console.ReadKey();
        }
    }
}
