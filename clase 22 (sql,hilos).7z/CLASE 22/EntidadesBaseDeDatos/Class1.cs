﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace EntidadesBaseDeDatos
{
    public class Persona
    {
                
        private string _nombre;
        private string _apellido;
        private int _edad;
        private int _id;

        #region Propiedad/es
        public string Nombre
        { 
            get { return this._nombre; }
            set { this._nombre = value; }
        }
        public string Apellido
        {
            get { return this._apellido; }
            set { this._apellido = value; }
        }
        public int Edad
        {
            get { return this._edad; }
            set { this._edad = value; }
        }
        public int Id
        {
            get { return this._id; }
        }
        #endregion

        #region Constructor/es
        public Persona(string nom, string ape, int edad)
        {
            this._apellido = ape;
            this._nombre = nom;
            this._edad = edad;
        }
        public Persona(string nom, string ape, int edad, int id)
        {
            this._apellido = ape;
            this._nombre = nom;
            this._edad = edad;
            this._id = id;
        }
        #endregion

        public static List<Persona> TraerTodos()
        {
            List<Persona> retorna = new List<Persona>();

            SqlConnection Obj_sql_conexion = new SqlConnection(Properties.Settings.Default.Servidor);

            Obj_sql_conexion.Open();

            SqlCommand comando = new SqlCommand("SELECT [id],[nombre],[apellido],[edad] FROM [Padron].[dbo].[Personas]", Obj_sql_conexion);

            SqlDataReader sql = comando.ExecuteReader();

            while (sql.Read())
            {
                retorna.Add(new Persona(sql["nombre"].ToString(),sql["apellido"].ToString(),(int)sql["edad"],(int)sql["id"]));
            }
            sql.Close();
            Obj_sql_conexion.Close();

            return retorna;
        }

        public bool Agregar()
        {
            bool retorno = false;
            try
            {
                           
                SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Servidor);

            conexion.Open();

            SqlCommand comando = new SqlCommand("INSERT INTO [Padron].[dbo].[Personas]([nombre],[apellido],[edad]) VALUES ('"+this._nombre+"','"+this._apellido+"',"+this._edad+")",conexion);

            comando.ExecuteNonQuery();

            conexion.Close();

            retorno = true;
            }
            catch(Exception Excep)
            {
                Console.WriteLine(Excep.Message);
            }

            return retorno;
        }

        public static bool Borrar(Persona X)
        {
            bool Retorno = false;

            try
            {
                SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Servidor);

                conexion.Open();

                SqlCommand comando = new SqlCommand("DELETE FROM [Padron].[dbo].[Personas] WHERE [id]= "+X._id, conexion);

                comando.ExecuteNonQuery();

                conexion.Close();

                Retorno = true;
            }
            catch (Exception excep)
            {
                Console.WriteLine(excep.Message);
            }


            return Retorno;
        }


        public bool Modificar()
        {
            bool Retorno = false;

            try
            {
                SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Servidor);

                conexion.Open();

                SqlCommand comando = new SqlCommand("UPDATE [Padron].[dbo].[Personas] SET [nombre] = '"+this.Nombre+"',[apellido] = '"+this.Apellido+"',[edad] ="+this.Edad+" WHERE [id]= 11 ", conexion);

                comando.ExecuteNonQuery();

                conexion.Close();

                Retorno = true;
            }
            catch (Exception excep)
            {
                Console.WriteLine(excep.Message);
            }


            return Retorno;
        }

        public static Persona TraerTodos(int IDbusqueda)
        {
            Persona retorno = null;

            try
            {

                SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Servidor);

                conexion.Open();

                SqlCommand comando = new SqlCommand("SELECT [id],[nombre],[apellido],[edad] FROM [Padron].[dbo].[Personas] WHERE [id]= " +IDbusqueda, conexion);

                SqlDataReader SqlDataReader = comando.ExecuteReader();

                if (SqlDataReader.Read())
                {
                    retorno = new Persona((string)(SqlDataReader["[nombre]"]),(string)(SqlDataReader["[apellido]"],(int)(SqlDataReader["[edad]"]),(int)(SqlDataReader["[id]"]));
                }

                conexion.Close();
                SqlDataReader.Close();

            }
            catch (Exception excep)
            {
                Console.WriteLine(excep.Message);
            }

            return retorno;
        }

        public static DataTable TraerTodosTabla()
        {
            DataTable Tabla = new DataTable();

            try
            {
                // DataTable ejem ->> new && DataTable ejem ->> DataRow ->> DataColum
                SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Servidor);

                conexion.Open();

                SqlCommand comando = new SqlCommand("SELECT [id],[nombre],[apellido],[edad] FROM [Padron].[dbo].[Personas]", conexion);

                SqlDataReader SqlDataReader = comando.ExecuteReader();

                Tabla.Load(SqlDataReader);

                //comando.ExecuteNonQuery();

                conexion.Close();
                SqlDataReader.Close();

            }
            catch (Exception excep)
            {

            }
            

            return Tabla;
        }

        public override string ToString()
        {
            return (this.Nombre + "-" + this.Apellido + "-" + this.Edad + "-" + this.Id );
        }
    }
}
