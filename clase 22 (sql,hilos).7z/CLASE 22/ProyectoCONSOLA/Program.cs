﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesBaseDeDatos;
using System.Data;

namespace ProyectoCONSOLA
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach (Persona item in Persona.TraerTodos())
            {
                Console.WriteLine(item.ToString());

            }

            
            Console.ReadLine();
            Console.Clear();

            Persona prueba1 = new Persona("Ana", "La de Frozen", 15,10);

            /*
            if (prueba1.Agregar())
            {
                foreach (Persona item in Persona.TraerTodos())
                {
                    Console.WriteLine(item.ToString());
                }
            }

            Console.ReadLine();
            Console.Clear();
            */
            /*
            if(Persona.Borrar(prueba1))
            {
                foreach (Persona item in Persona.TraerTodos())
                {
                    Console.WriteLine(item.ToString());
                }
            }
            */

            if (prueba1.Modificar())
            {
                Console.WriteLine(prueba1.ToString());
            }


            Console.ReadKey();

            DataTable recibe = Persona.TraerTodosTabla();

            
            
        }


    }
}
