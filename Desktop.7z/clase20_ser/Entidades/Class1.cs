﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;


namespace Entidades
{
    [Serializable]
    [XmlInclude(typeof(Alumno))]
    [XmlInclude(typeof(Profesor))]
    public abstract class Persona
    {
        private string _nombre;
        private string _apellido;
        private int _dni;

        public Persona()
        {

        }
        public Persona(string nom, string ape, int dni)
        {
            this._nombre = nom;
            this._apellido = ape;
            this._dni = dni;
        }

        public override string ToString()
        {
            return (this._nombre + "--" + this._apellido + "--" + this._dni);
        }
    }



    public class Alumno : Persona
    {
        public int _legajo;

        public Alumno()
        {

        }
        public Alumno(string name, string surname, int dni, int legajo)
            : base(name,surname,dni)
        {
            this._legajo = legajo;
        }

        public override string ToString()
        {
            return (base.ToString() + "--" + this._legajo );
        }
    }

    public class Profesor : Persona
    {
        public string _titulo;


        public Profesor()
        {

        }
        public Profesor(string name, string surname,int dni, string titulo )
            : base(name,surname,dni)
        {
            this._titulo = titulo;
        }

        public override string ToString()
        {
            return (base.ToString() + "--" + this._titulo);
        }
    }

    public class Aula
    {
        private int _numero;
        private List<Persona> _lista;


        public int Numero { get { return this._numero; } set { this._numero = value; } }

        public List<Persona> ListaPersonas { get { return this._lista; } }


        public Aula() { }

        public Aula(int num)
        {
            this._numero = num;
            this._lista = new List<Persona>();
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            foreach (Persona item in this._lista)
            {
                if (item is Profesor)
                {
                    retorno.Append(((Profesor)item).ToString());
                }
                if (item is Alumno)
                {
                    retorno.Append(((Alumno)item).ToString());
                }
            }

            return retorno.ToString();
        }

        public static bool GenerarXML(string path, Alumno n)
        {
            bool retorno = false;
            try
            {
                XmlTextWriter escribe = new XmlTextWriter(path,Encoding.UTF8);

                XmlSerializer escribearchivo = new XmlSerializer(typeof(Alumno));

                escribearchivo.Serialize(escribe, n);

                retorno = true;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return retorno;
        }

        public static bool LeerXML(string a,out Alumno n)
        {    
            n = new Alumno("", "", 0, 0);

            bool retorno = false;

            try
            {
                XmlTextReader lee = new XmlTextReader(a);
                XmlSerializer xml = new XmlSerializer(typeof(Alumno));

                n = (Alumno)xml.Deserialize(lee);
                lee.Close();
                retorno = true;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return retorno;
        }
    }

    public class XML<T>
    {
        public  bool GenerarXML(string path, T n)
        {
            bool retorno = false;
            try
            {
                XmlTextWriter Archivo = new XmlTextWriter(path,Encoding.UTF8);

                XmlSerializer escribearchivo = new XmlSerializer(typeof(T));

                escribearchivo.Serialize(Archivo, n);

                retorno = true;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return retorno;       
        }

        public  bool LeerXML(string path, out T n)
        {
            bool retorno = false;
            //n = default(T);

            //try
            //{
                XmlTextReader lee = new XmlTextReader(path);
                XmlSerializer xml = new XmlSerializer(typeof(T));

                n = (T)xml.Deserialize(lee);
                lee.Close();
                retorno = true;
            //}
            //catch(Exception e)
            //{

          
            //    Console.WriteLine(e.Message);
                
            //}

            return retorno;
        }
    }
}
