﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Pruebo
{
    class Program
    {
        static void Main(string[] args)
        {
            Profesor profe = new Profesor("jorge", "perez", 111111, "sociales");
            Profesor aux;

            Alumno A1 = new Alumno("A", "A", 1, 1);
            Alumno A2 = new Alumno("B", "B", 2, 2);
            Alumno A3 = new Alumno("C", "C", 3, 3);
            Alumno A4 = new Alumno("D", "D", 3, 3);

            XML<List<Persona>> lista = new XML<List<Persona>>();

            List<Persona> LISTApersonas = new List<Persona>();

            //if (lista.LeerXML(@"aula.xml", out LISTApersonas))
            //{

            //}

            LISTApersonas.Add(A1);
            LISTApersonas.Add(A2);
            LISTApersonas.Add(A3);
            LISTApersonas.Add(A4);

            
            if (lista.GenerarXML(@"aula.xml", LISTApersonas))
            {
                Console.WriteLine("creado con exito");
            }


            if (lista.LeerXML(@"aula.xml", out LISTApersonas))
            {
                Console.WriteLine(LISTApersonas.ToString());
            }
            //XML<Persona>.GenerarXML(@"aula.xml", profe);
            //XML<Persona>.GenerarXML(@"aula.xml", A1);
            //XML<Persona>.GenerarXML(@"aula.xml", A2);
            //XML<Persona>.GenerarXML(@"aula.xml", A3);
            //XML<Persona>.GenerarXML(@"aula.xml", A4);


            //XML<Persona>.LeerXML(@"aula.dat",out aux);

            Console.ReadLine();
        }
    }
}
