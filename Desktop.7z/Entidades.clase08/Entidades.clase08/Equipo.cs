﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.clase08
{
    public class Equipo
    {
        private short cantidaddejugadores;
        private string nombre;
        private List<Jugador> jugadores;


        private Equipo()
        {
            this.jugadores = new List<Jugador>();

        }

        public Equipo(short cantidad, string nombre)
            : this()
        {
            this.cantidaddejugadores = cantidad;
            this.nombre = nombre;
        }

        public static Boolean operator +(Equipo equipo, Jugador J)
        {
            Boolean retorno = false;
            bool bandera = false;

            foreach (Jugador acum in equipo.jugadores)
            {
                if (acum == J)
                {
                    bandera = true;
                }
            }

            if (bandera == false && equipo.cantidaddejugadores > equipo.jugadores.Count())
            {
                equipo.jugadores.Add(J);
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator -(Equipo equipo, Jugador J)
        {
            Boolean retorno = false;
            bool bandera = false;
            int i = 0;

            foreach (Jugador acum in equipo.jugadores)
            {
                i++;
                if (acum == J)
                {
                    bandera = true;
                    break;
                }
            }

            if (bandera == true)
            {
                equipo.jugadores.RemoveAt(i);
                retorno = true;
            }

            return retorno;
        }

        public List<Jugador> GetJugadores()
        {
            return this.jugadores;
        }
    }
}
