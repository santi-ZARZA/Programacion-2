﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.clase08
{
    public class Jugador
    {
        private long dni;
        private string nombre;
        private int partidosjugados;
        private float promedioGoles;
        private int totalgoles;

        public long Dni { get { return this.dni; } }
        public string Nombre { get { return this.nombre; } set { this.nombre = value; } }
        public int PartidosJugados { get { return this.partidosjugados; } set { this.partidosjugados = value; } }
        public int TotalGoles { get { return this.totalgoles; } set { this.totalgoles = value; } }



        private Jugador()
        {
            this.dni = 1;
            this.nombre = "sin nombre";
            this.partidosjugados = 0;
            this.totalgoles = 0;
            this.promedioGoles = 0;
        }

        public Jugador(string nombre,long dni):this()
        {
            this.nombre = nombre;
            this.dni = dni;
        }

        public Jugador(string nombre, long dni, int totalgoles,int totalpartidos):this(nombre,dni)
        {
            this.totalgoles = totalgoles;
            this.partidosjugados = totalpartidos;
        }

        public float getPromedioGoles()
        {
           return this.promedioGoles = (float)this.totalgoles / (float)this.partidosjugados;
        }

        public static Boolean operator ==(Jugador J1, Jugador J2)
        {
            Boolean retorno = false;

            if (J1.dni == J2.dni)
            {
                retorno = true;
            }

            return retorno;
        }

        public static Boolean operator !=(Jugador J1, Jugador J2)
        {
            return !(J1 == J2);
        }

        public string MostrarDatos()
        {
            string retorno = "";

            retorno += "DNI: " + this.dni + "\n";
            retorno += "Nombre: " + this.nombre + "\n";
            retorno += "P/J: " + this.partidosjugados + "\n";
            retorno += "Goles: " + this.totalgoles + "\n";
           // retorno += "Prom/Goles: " + this.promedioGoles + "\n";

            return retorno;
        }
    }
}
