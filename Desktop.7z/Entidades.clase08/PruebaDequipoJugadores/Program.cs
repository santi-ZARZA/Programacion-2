﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.clase08;

namespace PruebaDequipoJugadores
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador J1 = new Jugador("juan",11111,10,10);
            Jugador J2 = new Jugador("dario", 222222,5,20);
            Jugador J3 = new Jugador("mariano", 1133111,15,20);
            Jugador J4 = new Jugador("luis", 44444,3,1);
            Jugador J5 = new Jugador("carlos", 55555,4,4);

            Console.WriteLine("Mis nuevos jugadores:");
            Console.WriteLine(J1.MostrarDatos());
            Console.WriteLine(J2.MostrarDatos());
            Console.WriteLine(J3.MostrarDatos());
            Console.WriteLine(J4.MostrarDatos());
            Console.WriteLine(J5.MostrarDatos());
            Console.ReadKey();

            Console.WriteLine("los promedios de gol son:");
            Console.WriteLine(J1.getPromedioGoles());
            Console.WriteLine(J2.getPromedioGoles());
            Console.WriteLine(J3.getPromedioGoles());
            Console.WriteLine(J4.getPromedioGoles());
            Console.WriteLine(J5.getPromedioGoles());
            Console.ReadKey();
        }
    }
}
