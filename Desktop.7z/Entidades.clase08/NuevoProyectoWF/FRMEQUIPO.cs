﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.clase08;

namespace NuevoProyectoWF
{
    public partial class FRMEQUIPO : Form
    {
        private Equipo equipo;
        bool bandera;
        Jugador jugador;

        public FRMEQUIPO()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            this.equipo = new Equipo(short.Parse(this.txt_cant_jugadores.Text), this.txt_nombre.Text);

            this.btn_cancelar.Enabled = false;
            this.btn_cancelar.Visible = false;
            this.txt_nombre.Enabled = true;
            this.txt_cant_jugadores.Enabled = true;
            this.btn_aceptar.Enabled = false;
            this.btn_aceptar.Visible = false;
            this.list.Visible = true;
            this.btn_suma.Visible = true;

        }

        private void ActualizarListBox()
        {
            this.list.Items.Clear();

            foreach (Jugador acum in this.equipo.GetJugadores())
            {
                this.list.Items.Add(acum.MostrarDatos());
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_suma_Click(object sender, EventArgs e)
        {
            FRMjugador windJugador = new FRMjugador();

            windJugador.ShowDialog();

            if (windJugador.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                jugador = windJugador.GetJugador();

                bandera = equipo + jugador;

                if (bandera)
                {
                    this.ActualizarListBox();
                   // MessageBox.Show("carga correcta");
                }
                else
                {
                    //MessageBox.Show("no se pudo cargar");
                }
            }

            if (this.list.Items.Count >= 1)
            {
                this.btn_menos.Enabled = true;
                this.btn_menos.Visible = true;
                this.btn_Modificar.Enabled = true;
                this.btn_Modificar.Visible = true;
            }
        }

        private void btn_menos_Click(object sender, EventArgs e)
        {

            if (this.list.SelectedIndex != -1)
            {
                FRMjugador jugadoraborrar = new FRMjugador();

                jugadoraborrar.ShowDialog();





            }
        }

        private void btn_Modificar_Click(object sender, EventArgs e)
        {
            if (this.list.SelectedIndex != -1)
            {
                FRMjugador jugadoraborrar = new FRMjugador(this.equipo.GetJugadores()[this.list.SelectedIndex]);

                jugadoraborrar.ShowDialog();

                



            }
        }


    }
}
