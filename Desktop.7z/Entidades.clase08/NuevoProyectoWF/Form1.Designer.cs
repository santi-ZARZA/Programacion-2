﻿namespace NuevoProyectoWF
{
    partial class FRMjugador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelDNI = new System.Windows.Forms.Label();
            this.labelNOMBRE = new System.Windows.Forms.Label();
            this.labelPAR_JUGADOS = new System.Windows.Forms.Label();
            this.labelGOLES = new System.Windows.Forms.Label();
            this.textBox_DNI = new System.Windows.Forms.TextBox();
            this.textBox_NOMBRE = new System.Windows.Forms.TextBox();
            this.textBox_PAR_JUGADOS = new System.Windows.Forms.TextBox();
            this.textBoxGOLES = new System.Windows.Forms.TextBox();
            this.buttonACEPTAR = new System.Windows.Forms.Button();
            this.buttonCANCELAR = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelDNI
            // 
            this.labelDNI.AutoSize = true;
            this.labelDNI.BackColor = System.Drawing.SystemColors.Control;
            this.labelDNI.Location = new System.Drawing.Point(12, 9);
            this.labelDNI.Name = "labelDNI";
            this.labelDNI.Size = new System.Drawing.Size(26, 13);
            this.labelDNI.TabIndex = 0;
            this.labelDNI.Text = "DNI";
            // 
            // labelNOMBRE
            // 
            this.labelNOMBRE.AutoSize = true;
            this.labelNOMBRE.Location = new System.Drawing.Point(12, 64);
            this.labelNOMBRE.Name = "labelNOMBRE";
            this.labelNOMBRE.Size = new System.Drawing.Size(54, 13);
            this.labelNOMBRE.TabIndex = 1;
            this.labelNOMBRE.Text = "NOMBRE";
            // 
            // labelPAR_JUGADOS
            // 
            this.labelPAR_JUGADOS.AutoSize = true;
            this.labelPAR_JUGADOS.Location = new System.Drawing.Point(12, 114);
            this.labelPAR_JUGADOS.Name = "labelPAR_JUGADOS";
            this.labelPAR_JUGADOS.Size = new System.Drawing.Size(116, 13);
            this.labelPAR_JUGADOS.TabIndex = 2;
            this.labelPAR_JUGADOS.Text = "PARTIDOS JUGADOS";
            // 
            // labelGOLES
            // 
            this.labelGOLES.AutoSize = true;
            this.labelGOLES.Location = new System.Drawing.Point(12, 171);
            this.labelGOLES.Name = "labelGOLES";
            this.labelGOLES.Size = new System.Drawing.Size(43, 13);
            this.labelGOLES.TabIndex = 3;
            this.labelGOLES.Text = "GOLES";
            // 
            // textBox_DNI
            // 
            this.textBox_DNI.Location = new System.Drawing.Point(12, 41);
            this.textBox_DNI.Name = "textBox_DNI";
            this.textBox_DNI.Size = new System.Drawing.Size(100, 20);
            this.textBox_DNI.TabIndex = 4;
            // 
            // textBox_NOMBRE
            // 
            this.textBox_NOMBRE.Location = new System.Drawing.Point(15, 91);
            this.textBox_NOMBRE.Name = "textBox_NOMBRE";
            this.textBox_NOMBRE.Size = new System.Drawing.Size(100, 20);
            this.textBox_NOMBRE.TabIndex = 5;
            // 
            // textBox_PAR_JUGADOS
            // 
            this.textBox_PAR_JUGADOS.Location = new System.Drawing.Point(12, 148);
            this.textBox_PAR_JUGADOS.Name = "textBox_PAR_JUGADOS";
            this.textBox_PAR_JUGADOS.Size = new System.Drawing.Size(100, 20);
            this.textBox_PAR_JUGADOS.TabIndex = 6;
            // 
            // textBoxGOLES
            // 
            this.textBoxGOLES.Location = new System.Drawing.Point(12, 201);
            this.textBoxGOLES.Name = "textBoxGOLES";
            this.textBoxGOLES.Size = new System.Drawing.Size(100, 20);
            this.textBoxGOLES.TabIndex = 7;
            // 
            // buttonACEPTAR
            // 
            this.buttonACEPTAR.Location = new System.Drawing.Point(15, 227);
            this.buttonACEPTAR.Name = "buttonACEPTAR";
            this.buttonACEPTAR.Size = new System.Drawing.Size(75, 23);
            this.buttonACEPTAR.TabIndex = 8;
            this.buttonACEPTAR.Text = "Aceptar";
            this.buttonACEPTAR.UseVisualStyleBackColor = true;
            this.buttonACEPTAR.Click += new System.EventHandler(this.buttonACEPTAR_Click);
            // 
            // buttonCANCELAR
            // 
            this.buttonCANCELAR.Location = new System.Drawing.Point(197, 227);
            this.buttonCANCELAR.Name = "buttonCANCELAR";
            this.buttonCANCELAR.Size = new System.Drawing.Size(75, 23);
            this.buttonCANCELAR.TabIndex = 9;
            this.buttonCANCELAR.Text = "Cancelar";
            this.buttonCANCELAR.UseVisualStyleBackColor = true;
            this.buttonCANCELAR.Click += new System.EventHandler(this.buttonCANCELAR_Click);
            // 
            // FRMjugador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.buttonCANCELAR);
            this.Controls.Add(this.buttonACEPTAR);
            this.Controls.Add(this.textBoxGOLES);
            this.Controls.Add(this.textBox_PAR_JUGADOS);
            this.Controls.Add(this.textBox_NOMBRE);
            this.Controls.Add(this.textBox_DNI);
            this.Controls.Add(this.labelGOLES);
            this.Controls.Add(this.labelPAR_JUGADOS);
            this.Controls.Add(this.labelNOMBRE);
            this.Controls.Add(this.labelDNI);
            this.Name = "FRMjugador";
            this.Text = "FRMjugador";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelDNI;
        private System.Windows.Forms.Label labelNOMBRE;
        private System.Windows.Forms.Label labelPAR_JUGADOS;
        private System.Windows.Forms.Label labelGOLES;
        private System.Windows.Forms.TextBox textBox_DNI;
        private System.Windows.Forms.TextBox textBox_NOMBRE;
        private System.Windows.Forms.TextBox textBox_PAR_JUGADOS;
        private System.Windows.Forms.TextBox textBoxGOLES;
        private System.Windows.Forms.Button buttonACEPTAR;
        private System.Windows.Forms.Button buttonCANCELAR;
    }
}

