﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.clase08;

namespace NuevoProyectoWF
{
    public partial class FRMjugador : Form
    {
        private Jugador jugador;

        public FRMjugador()
        {
            InitializeComponent();
        }

        public FRMjugador(Jugador x):this()
        {
            jugador = x;
            this.textBox_DNI.Text = jugador.Dni.ToString();
            this.textBox_NOMBRE.Text = jugador.Nombre;
            this.textBox_PAR_JUGADOS.Text = jugador.TotalGoles.ToString();
            this.textBoxGOLES.Text = jugador.PartidosJugados.ToString();

            this.textBox_DNI.Enabled = false;
        }

        public Jugador GetJugador()
        {
            return this.jugador;
        }


        private void buttonACEPTAR_Click(object sender, EventArgs e)
        {
            if (jugador != null)
            {
                jugador.Nombre = this.textBox_NOMBRE.Text;
                jugador.PartidosJugados = int.Parse(this.textBox_PAR_JUGADOS.Text);
                jugador.TotalGoles = int.Parse(this.textBoxGOLES.Text);
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
            else
            {
                jugador = new Jugador(this.textBox_NOMBRE.Text, long.Parse(this.textBox_DNI.Text), int.Parse(this.textBox_PAR_JUGADOS.Text), int.Parse(this.textBoxGOLES.Text));
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
         
            
        }

        private void buttonCANCELAR_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }


    }
}
