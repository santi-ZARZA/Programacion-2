﻿namespace NuevoProyectoWF
{
    partial class FRMEQUIPO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_aceptar = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.label_nombre = new System.Windows.Forms.Label();
            this.label_cant_jugadores = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_cant_jugadores = new System.Windows.Forms.TextBox();
            this.list = new System.Windows.Forms.ListBox();
            this.btn_suma = new System.Windows.Forms.Button();
            this.btn_menos = new System.Windows.Forms.Button();
            this.btn_Modificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_aceptar
            // 
            this.btn_aceptar.Location = new System.Drawing.Point(28, 84);
            this.btn_aceptar.Name = "btn_aceptar";
            this.btn_aceptar.Size = new System.Drawing.Size(75, 23);
            this.btn_aceptar.TabIndex = 0;
            this.btn_aceptar.Text = "Aceptar";
            this.btn_aceptar.UseVisualStyleBackColor = true;
            this.btn_aceptar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.Location = new System.Drawing.Point(185, 84);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(75, 23);
            this.btn_cancelar.TabIndex = 1;
            this.btn_cancelar.Text = "Cancelar";
            this.btn_cancelar.UseVisualStyleBackColor = true;
            // 
            // label_nombre
            // 
            this.label_nombre.AutoSize = true;
            this.label_nombre.Location = new System.Drawing.Point(34, 16);
            this.label_nombre.Name = "label_nombre";
            this.label_nombre.Size = new System.Drawing.Size(44, 13);
            this.label_nombre.TabIndex = 2;
            this.label_nombre.Text = "Nombre";
            // 
            // label_cant_jugadores
            // 
            this.label_cant_jugadores.AutoSize = true;
            this.label_cant_jugadores.Location = new System.Drawing.Point(34, 45);
            this.label_cant_jugadores.Name = "label_cant_jugadores";
            this.label_cant_jugadores.Size = new System.Drawing.Size(78, 13);
            this.label_cant_jugadores.TabIndex = 3;
            this.label_cant_jugadores.Text = "Cant jugadores";
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(117, 13);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(143, 20);
            this.txt_nombre.TabIndex = 4;
            // 
            // txt_cant_jugadores
            // 
            this.txt_cant_jugadores.Location = new System.Drawing.Point(117, 42);
            this.txt_cant_jugadores.Name = "txt_cant_jugadores";
            this.txt_cant_jugadores.Size = new System.Drawing.Size(143, 20);
            this.txt_cant_jugadores.TabIndex = 5;
            // 
            // list
            // 
            this.list.FormattingEnabled = true;
            this.list.Location = new System.Drawing.Point(4, 113);
            this.list.Name = "list";
            this.list.Size = new System.Drawing.Size(284, 121);
            this.list.TabIndex = 6;
            this.list.Visible = false;
            // 
            // btn_suma
            // 
            this.btn_suma.Location = new System.Drawing.Point(12, 242);
            this.btn_suma.Name = "btn_suma";
            this.btn_suma.Size = new System.Drawing.Size(75, 23);
            this.btn_suma.TabIndex = 7;
            this.btn_suma.Text = "+";
            this.btn_suma.UseVisualStyleBackColor = true;
            this.btn_suma.Visible = false;
            this.btn_suma.Click += new System.EventHandler(this.btn_suma_Click);
            // 
            // btn_menos
            // 
            this.btn_menos.Location = new System.Drawing.Point(213, 242);
            this.btn_menos.Name = "btn_menos";
            this.btn_menos.Size = new System.Drawing.Size(75, 23);
            this.btn_menos.TabIndex = 8;
            this.btn_menos.Text = "-";
            this.btn_menos.UseVisualStyleBackColor = true;
            this.btn_menos.Visible = false;
            this.btn_menos.Click += new System.EventHandler(this.btn_menos_Click);
            // 
            // btn_Modificar
            // 
            this.btn_Modificar.Location = new System.Drawing.Point(113, 242);
            this.btn_Modificar.Name = "btn_Modificar";
            this.btn_Modificar.Size = new System.Drawing.Size(75, 23);
            this.btn_Modificar.TabIndex = 10;
            this.btn_Modificar.Text = "M";
            this.btn_Modificar.UseVisualStyleBackColor = true;
            this.btn_Modificar.Visible = false;
            this.btn_Modificar.Click += new System.EventHandler(this.btn_Modificar_Click);
            // 
            // FRMEQUIPO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 277);
            this.Controls.Add(this.btn_Modificar);
            this.Controls.Add(this.btn_menos);
            this.Controls.Add(this.btn_suma);
            this.Controls.Add(this.list);
            this.Controls.Add(this.txt_cant_jugadores);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.label_cant_jugadores);
            this.Controls.Add(this.label_nombre);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btn_aceptar);
            this.Name = "FRMEQUIPO";
            this.Text = "Equipo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_aceptar;
        private System.Windows.Forms.Button btn_cancelar;
        private System.Windows.Forms.Label label_nombre;
        private System.Windows.Forms.Label label_cant_jugadores;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_cant_jugadores;
        private System.Windows.Forms.ListBox list;
        private System.Windows.Forms.Button btn_suma;
        private System.Windows.Forms.Button btn_menos;
        private System.Windows.Forms.Button btn_Modificar;
    }
}