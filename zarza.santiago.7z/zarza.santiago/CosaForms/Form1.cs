﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SpaceCosa;

namespace CosaForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string aux1, aux2, aux3;
            
            

            aux1 = textBox1.Text;
            aux2 = textBox2.Text;
            aux3 = textBox3.Text;

            Cosa cosanueva = new Cosa(int.Parse(aux2),aux1,DateTime.Parse(aux3));

            MessageBox.Show(cosanueva.Mostrar());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
