﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SpaceCosa;

namespace clase04
{
    class Program
    {
        static void Main(string[] args)
        {
            Cosa cosa1 = new Cosa();

            Console.WriteLine(cosa1.Mostrar());

            cosa1.EstablecerValor(1);
            cosa1.EstablecerValor("palabra");
            cosa1.EstablecerValor(DateTime.Now);

            Console.ReadLine();

            Console.WriteLine();

            Console.WriteLine(cosa1.Mostrar());


            Console.ReadKey();
        }
    }
}
