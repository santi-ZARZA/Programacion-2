﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosaSpace
{
    class Cosa
    {
        public int entero;
        public string cadena;
        public DateTime datetime;


        public Cosa()
        {
            entero = 10;
            cadena = "sin valor";
            datetime = DateTime.Now;

        }

        public Cosa(int x, string z, DateTime j)
        {
            entero = x;
            cadena = z;
            datetime = j;

        }

        public Cosa(int x, string z)
        {
            entero = x;
            cadena = z;
            datetime = DateTime.Now;

        }

        public Cosa(int x)
        {
            entero = x;
            cadena = "sin valor";
            datetime = DateTime.Now;

        }

        /// <summary>
        ///     Recibe un valor entero y lo asigna a un atributo entero
        /// </summary>
        /// <param name="x"></param>
        public void EstablecerValor(int x)
        {
            this.entero = x;
        }
        /// <summary>
        /// Recibe un valor String y lo asigna a un atributo String
        /// </summary>
        /// <param name="x"></param>
        public void EstablecerValor(string x)
        {
            this.cadena = x;
        }
        /// <summary>
        /// Recibe un valor DateTime y lo asigna a un atributo DateTime
        /// </summary>
        /// <param name="x"></param>
        public void EstablecerValor(DateTime x)
        {
            this.datetime = x;
        }
        /// <summary>
        /// Concatena los atributos y los devuelve en un string
        /// </summary>
        /// <returns></returns>
        public string Mostrar()
        {
            string retorno = "";

            retorno = this.cadena + "\n" + this.entero + "\n" + this.datetime + "\n";

            
            return retorno;
        
        }

    }
}
