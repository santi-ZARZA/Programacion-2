﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioClase04
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassLibrary1.cosa cosa1 = new Cosa();

            Console.Write(cosa1.)

            cosa1.EstablecerValor(1);
            cosa1.EstablecerValor("palabra");
            cosa1.EstablecerValor(DateTime.Now);

            

           
            
        }
    }
}
