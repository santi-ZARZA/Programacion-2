using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ENTIDADES.SP
{
  [Serializable]
  [XmlInclude(typeof(Manzana))]
  public class Cajon<T>: ISerializar
  {
    protected int _capacidad;
    protected List<T> _elementos;
    protected double _precioUnitario;

    public Cajon()
    {
      this._elementos = new List<T>();
    }

    public Cajon(int capacidad): this()
    {
      this._capacidad = capacidad;
    }

    public Cajon(double precioUnitario, int capacidad) : this(capacidad)
    {
      this._precioUnitario = precioUnitario;
    }

    public List<T> Elementos { get { return this._elementos; } }

    public double PrecioTotal { get { return (this._precioUnitario * this._elementos.Count); } }

    public override string ToString()
    {
      StringBuilder builder = new StringBuilder("Capacidad: "+this._capacidad+" -- Cantidad De Total Elementos: "+this._elementos.Count+"\n");
      foreach (T item in this._elementos)
      {
        if (item != null)
        {
          builder.Append(item.ToString() + "\n");
        }
      }
      return builder.ToString();
    }

    public bool Xml(string Archivo)
    {
      bool retorno = false;
      XmlSerializer serializer = null;
      XmlTextWriter textWriter = null;


      try
      {
        serializer = new XmlSerializer(typeof(T));
        textWriter = new XmlTextWriter(Archivo, Encoding.UTF8);

        serializer.Serialize(textWriter, this);

        retorno = true;
      }
      catch (Exception excep)
      { }
      finally
      {
        textWriter.Close();
      }


      return retorno;
    }

    public static Cajon<T> operator +(Cajon<T> cajon, T elemento)
    {
      if(cajon._capacidad > cajon._elementos.Count)
      {
        cajon._elementos.Add(elemento);
      }
      else
      {
        throw new CajonLlenoException();
      }
      return cajon;
    }
  }
}
