using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ENTIDADES.SP
{
  [Serializable]
  public class Manzana : Fruta , ISerializar , IDeserializar
  {
    protected string _provinciaOrigen;

    public Manzana():this("ninguno",0,"sin pais")
    {
    }

    public Manzana(string color,double peso,string provinciaOrigen): base(color,peso)
    {
      this._provinciaOrigen = provinciaOrigen;
    }

    public string Nombre { get { return "Manzana"; } }

    public override bool TieneCarozo { get { return true; } }

    public override string ToString()
    {
      return string.Format("{0} -- {1} -- Tiene Carozo : {2}",this.Nombre, base.FrutaToString(),this.TieneCarozo);
    }

    public bool Xml(string Archivo)
    {
      bool retorno = false;
      XmlSerializer serializer = null;
      XmlTextWriter textWriter = null;

      try
      {
        serializer = new XmlSerializer(typeof(Manzana));
        textWriter = new XmlTextWriter(Archivo, Encoding.UTF8);

        serializer.Serialize(textWriter, this);

        retorno = true;
      }
      catch (Exception excep)
      { }
      finally
      {
        textWriter.Close();
      }


      return retorno;
    }

    bool IDeserializar.Xml(string Archivo, out Fruta fruta)
    {
      bool retorno = false;
      fruta = null;

      XmlSerializer serializer = null;
      XmlTextReader textReader = null;

      try
      {
        serializer = new XmlSerializer(typeof(Manzana));
        textReader = new XmlTextReader(Archivo);

        fruta = ((Manzana)serializer.Deserialize(textReader));

        retorno = true;
      }
      catch (Exception excep)
      { }
      finally
      { textReader.Close(); }

      return retorno;
    }
  }
}
