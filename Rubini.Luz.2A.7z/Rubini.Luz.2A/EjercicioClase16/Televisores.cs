using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Xml;
using System.Data;
using System.Xml.Serialization;
namespace EjercicioClase16
{
    public class Televisores
    {
        public int codigo;
        public string marca;
        public float precio;
        public int pulgadas;
        public string pais;

        public Televisores(int codigo, string marca, float precio, int pulgadas, string pais)
        {
            this.codigo = codigo;
            this.marca = marca;
            this.precio = precio;
            this.pulgadas = pulgadas;
            this.pais = pais;
        }
        public Televisores()
        {
        }

        public bool Insertar()
        {
            bool retorno = false;


            //Primero Traemos los datos de la base de datos
            SqlCommand command = null;
            SqlConnection connection = null;


            try
            {
                // Creamos la Conexion Con La Base de Datos
                connection = new SqlConnection(Properties.Settings.Default.Conexion);
                // Abrimos la Conexion creada
                connection.Open();
                // Con los comandos Mandamos las directivas para Ingresar los datos a la tabla
                command = new SqlCommand("INSERT into [Productos].[dbo].[Televisores] ([codigo],[marca],[precio],[pulgadas],[pais]) VALUES (" + this.codigo + ",'" + this.marca + "'," + this.precio + "," + this.pulgadas + ",'" + this.pais + "')", connection);

                // Preguntamos si se pudo ingresar a la tabla algun nuevo objeto cargado
                int Afectados = command.ExecuteNonQuery();

                if(Afectados > 0)
                {
                    retorno = true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                // Cerramos las conexiones 
                // !!! SIEMPRE HAY QUE CERRARLAS -_- ¡¡¡
                connection.Close();
            }




            return retorno;
            /*bool retorno = false;
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand comando = new SqlCommand();
            comando.CommandText = "INSERT INTO Televisores VALUES ("+this.codigo+", '"+this.marca+"', "+this.precio+", "+this.pulgadas+", '"+this.pais+"')";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            return retorno;
            */
        }

        public static bool Modificar(Televisores tele)
        {
      bool retorno = false;


      //Primero Traemos los datos de la base de datos
      SqlCommand command = null;
      SqlConnection connection = null;


      try
      {
        // Creamos la Conexion Con La Base de Datos
        connection = new SqlConnection(Properties.Settings.Default.Conexion);
        // Abrimos la Conexion creada
        connection.Open();
        // Con los comandos Mandamos las directivas para Ingresar los datos a la tabla
        command = new SqlCommand("UPDATE [Productos].[dbo].[Televisores] SET [marca]  = '"+tele.marca+"',[precio] = "+tele.precio+",[pulgadas] = "+tele.pulgadas+ " WHERE [codigo] = "+tele.codigo+"", connection);

        // Preguntamos si se pudo ingresar a la tabla algun nuevo objeto cargado
        int Afectados = command.ExecuteNonQuery();

        if (Afectados > 0)
        {
          retorno = true;
        }
      }
      catch (Exception e)
      {
        Console.WriteLine(e.Message);
      }
      finally
      {
        // Cerramos las conexiones 
        // !!! SIEMPRE HAY QUE CERRARLAS -_- ¡¡¡
        connection.Close();
      }




      return retorno;
    }

        public static bool Borrar(Televisores tele)
    {
      bool retorno = false;


      //Primero Traemos los datos de la base de datos
      SqlCommand command = null;
      SqlConnection connection = null;


      try
      {
        // Creamos la Conexion Con La Base de Datos
        connection = new SqlConnection(Properties.Settings.Default.Conexion);
        // Abrimos la Conexion creada
        connection.Open();
        // Con los comandos Mandamos las directivas para Ingresar los datos a la tabla
        command = new SqlCommand("DELETE [Productos].[dbo].[Televisores] WHERE [codigo] = " + tele.codigo + "", connection);

        // Preguntamos si se pudo ingresar a la tabla algun nuevo objeto cargado
        int Afectados = command.ExecuteNonQuery();

        if (Afectados > 0)
        {
          retorno = true;
        }
      }
      catch (Exception e)
      {
        Console.WriteLine(e.Message);
      }
      finally
      {
        // Cerramos las conexiones 
        // !!! SIEMPRE HAY QUE CERRARLAS -_- ¡¡¡
        connection.Close();
      }




      return retorno;
    }

        public static List<Televisores> TraerTodos()
    {
      List<Televisores> retorno = null;
      //Primero Traemos los datos de la base de datos
      SqlCommand command = null;
      SqlConnection connection = null;
      SqlDataReader dataReader = null;


      try
      {
        // Creamos la Conexion Con La Base de Datos
        connection = new SqlConnection(Properties.Settings.Default.Conexion);
        // Abrimos la Conexion creada
        connection.Open();
        // Con los comandos Mandamos las directivas para Traer los datos de a tabla
        command = new SqlCommand("SELECT [codigo],[marca],[precio],[pulgadas],[pais] FROM [Productos].[dbo].[Televisores]", connection);
        // asignamos lo leido de la base a un lector de Base
        dataReader = command.ExecuteReader();

        retorno = new List<Televisores>();
        while (dataReader.Read())
        {
          int auxCod = ((int)dataReader["codigo"]);
          string auxMar = dataReader["marca"].ToString();
          float auxPre = float.Parse(dataReader["precio"].ToString());
          int auxPul = ((int)dataReader["pulgadas"]);
          string auxPai = dataReader["pais"].ToString();

          Televisores aux = new Televisores(auxCod,auxMar ,0f ,auxPul ,auxPai );

          retorno.Add(aux);
        }
    }
      catch (Exception e)
      {
        Console.WriteLine(e.Message);
      }
      finally
      {
        // Cerramos las conexiones 
        // !!! SIEMPRE HAY QUE CERRARLAS -_- ¡¡¡
        dataReader.Close();
        connection.Close();
      }

      return retorno;
    }

    public static Televisores TraerUno(int id)
    {
      Televisores retorno = null;
      //Primero Traemos los datos de la base de datos
      SqlCommand command = null;
      SqlConnection connection = null;
      SqlDataReader dataReader = null;


      try
      {
        // Creamos la Conexion Con La Base de Datos
        connection = new SqlConnection(Properties.Settings.Default.Conexion);
        // Abrimos la Conexion creada
        connection.Open();
        // Con los comandos Mandamos las directivas para Traer los datos de a tabla
        command = new SqlCommand("SELECT [codigo],[marca],[precio],[pulgadas],[pais] FROM [Productos].[dbo].[Televisores] WHERE [codigo] = "+id, connection);
        // asignamos lo leido de la base a un lector de Base
        dataReader = command.ExecuteReader();

        while (dataReader.Read())
        {
          int auxCod = int.Parse(dataReader["codigo"].ToString());
          string auxMar = dataReader["marca"].ToString();
          float auxPre = float.Parse(dataReader["precio"].ToString());
          int auxPul = ((int)dataReader["pulgadas"]);
          string auxPai = dataReader["pais"].ToString();

          retorno = new Televisores(auxCod, auxMar, auxPre, auxPul, auxPai);

        }


      }
      catch (Exception e)
      {
        Console.WriteLine(e.Message);
      }
      finally
      {
        // Cerramos las conexiones 
        // !!! SIEMPRE HAY QUE CERRARLAS -_- ¡¡¡
        dataReader.Close();
        connection.Close();
      }


      return retorno;
    }
  }
}
