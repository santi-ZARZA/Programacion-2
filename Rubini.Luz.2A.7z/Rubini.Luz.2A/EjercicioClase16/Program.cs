using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Xml;
using System.Data;
using System.Xml.Serialization;

namespace EjercicioClase16
{
    class Program
    {
        static void Main(string[] args)
        {
            //Primero Traemos los datos de la base de datos
            SqlCommand command = null;
            SqlConnection connection = null;
            SqlDataReader dataReader = null;

            // Creamos una Tabla de Base de Datos Propia
            DataTable dataTable = new DataTable("Televisores");

            try
            {
                // Creamos la Conexion Con La Base de Datos
                connection = new SqlConnection(Properties.Settings.Default.Conexion);
                // Abrimos la Conexion creada
                connection.Open();
                // Con los comandos Mandamos las directivas para Traer los datos de a tabla
                command = new SqlCommand("SELECT [codigo],[marca],[precio],[pulgadas],[pais] FROM [Productos].[dbo].[Televisores]", connection);
                // asignamos lo leido de la base a un lector de Base
                dataReader = command.ExecuteReader();

                // Hacemos la transferencia 
                // se Hace automaticamente al Hacerlo asi
                dataTable.Load(dataReader);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                // Cerramos las conexiones 
                // !!! SIEMPRE HAY QUE CERRARLAS -_- ¡¡¡
                dataReader.Close();
                connection.Close();
            }



      //Insertamos en la base de datos un "Televisor" nuevo

     Televisores televisores = new Televisores(3, "Truchex", 20, 2000, "Japon porque pinto");

      if (televisores.Insertar())
      {
        Console.WriteLine("Se Pudo ingresar en la Base de Datos");
      }
      else
      {
        Console.WriteLine("No se Pudo ingresar en la Base de Datos");
      }

      Console.ReadKey();

      ///////////////////////////////////////////////////////

      Televisores televisor = new Televisores(3, "HITACHI", 10, 10, "Argentina");

      if(Televisores.Modificar(televisor))
      {
        Console.WriteLine("Se Pudo Modificar");
      }
      else
      {
        Console.WriteLine(" No Se Pudo Modificar");
      }

      Console.ReadKey();

      //////////////////////////////////////////////////////////

      if(Televisores.Borrar(televisor))
      {
        Console.WriteLine("Se pudo Borrar.");
      }
      else
      {
        Console.WriteLine("No Se pudo Borrar.");
      }

      //////////////////////////////////////////////////////////


      List<Televisores> teles = Televisores.TraerTodos();

      if (teles != null)
      {
        Console.Clear();
        Console.WriteLine("Se pudieron traer todos de la base de datos.");
        foreach (Televisores item in teles)
        {
          Console.WriteLine(item.codigo + "-" + item.marca + "-" + item.pais);
        }
      }
      else
      {
        Console.Clear();
        Console.WriteLine(" No Se pudieron traer todos de la base de datos.");
      }

      Console.ReadKey();

      /////////////////////////////////////////////////////////////////////////

      Televisores Extraido = Televisores.TraerUno(123);

      if(Extraido != null)
      {
        Console.WriteLine("Se pudo Extraer el Adecuado de la base de datos.");
        Console.WriteLine(Extraido.codigo + "--" + Extraido.marca + "--" + Extraido.precio);

      }
      else
      {
        Console.WriteLine("No Se pudo Extraer el Adecuado de la base de datos.");
      }

      Console.ReadKey();
    }
    }
}
/*      
 *      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();
            
            comando.CommandText = "SELECT * FROM Televisores";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            conexion.Open();
            SqlDataReader lector = comando.ExecuteReader();
            List <Televisores> listaTelevisor = new List<Televisores>();
            while (lector.Read())
            {
                Console.WriteLine(lector[0] + "--" + lector[1] + "--" + lector[2] + "--" + lector[3] + "--" + lector[4]);
                Televisores t = new Televisores(lector.GetInt32(0), lector.GetString(1), lector.GetFloat(2), lector.GetInt32(3), lector.GetString(4)); 
                listaTelevisor.Add(t);
            }
            XmlSerializer sr = new XmlSerializer(typeof(List<Televisores>));
            XmlTextWriter wr = new XmlTextWriter(@"Televisores.Xml",Encoding.UTF32);
            XmlTextReader rd = new XmlTextReader("Televisores.Xml");
            sr.Deserialize(rd);
            List<Televisores> l = (List<Televisores>)sr.Deserialize(rd);
            sr.Serialize(wr,listaTelevisor);
            conexion.Close();
            Console.Read();
             
            /**
             * dataTable
             * conexion.Open();
            lector = comando.ExecuteReader();
            DataTable table = new DataTable("");
            */
