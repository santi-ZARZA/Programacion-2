﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Sello
    {
        public static string mensaje;
        public static ConsoleColor color;
        #region Metodos
        public static string Imprimir() { return Sello.ArmarFormatoMensaje(); }
        public static void Borrar() {  Sello.mensaje = ""; }
        public static void ImprimirEnColor()
        {
            Console.ForegroundColor = Sello.color;
            Console.WriteLine(Sello.Imprimir());
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        //Continuación del ejercicio de la clase 02:
        private static string ArmarFormatoMensaje()
        {
            string cadena = "", retorno = "", texto = "";
            if (Sello.TryParse(Sello.mensaje, out texto))
            {
                for (int i = 0; i < mensaje.Length + 2; i++)
                {
                    cadena += "*";
                }
                retorno = cadena + "\n*" + texto + "*\n" + cadena;
            }
            return retorno;
        }
        private static bool TryParse(string cadena, out string retornocadena)
        {
            bool retorno = false;
            retornocadena = "";
            if(cadena.Length > 0)
            {
                retorno = true;
                retornocadena = cadena;
            }
            return retorno;
            
        }
        #endregion
    }

}
