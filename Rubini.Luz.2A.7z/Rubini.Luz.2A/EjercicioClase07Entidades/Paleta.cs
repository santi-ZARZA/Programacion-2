﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase07Entidades
{
    public class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaximaElementos;
        /*public Tempera this[int i]
        { set
            {
                this._colores[i] = value;
            }-
        }*/
        #region Constructores
        private Paleta() : this(5)
        {

        }
        private Paleta(int cantidad)
        {
            this._cantMaximaElementos = cantidad;
            this._colores = new Tempera[_cantMaximaElementos];
        }
        #endregion
        #region Metodos
        private string Mostrar()
        {

            ; string retorno = "";
            foreach (Tempera unaTempera in this._colores)
            {
                if (!(Object.Equals(unaTempera, null)))
                {
                    retorno += unaTempera;
                    retorno += "\r\n";
                }
            }
            return retorno;
        }
        public static explicit operator string(Paleta paleta)
        {
            return paleta.Mostrar();
        }
        public static implicit operator Paleta(int cantidad)
        {

            return new Paleta(cantidad);
        }
        private int ObtenerIndice()
        {
            int indice = -1;
            int contador = 0;
            for (int i = 0; i < this._cantMaximaElementos; i++)
            {
                if (this._colores.GetValue(contador) == null)
                {
                    indice = i;
                    break;
                }
                contador++;
            }
            return indice;
        }
        private int ObtenerIndice(Tempera tempera)
        {
            int indice = -1;
            int contador = 0;

            for (int i = 0; i < this._cantMaximaElementos; i++)
            {
                if (tempera == (Tempera)this._colores.GetValue(contador))
                {
                    indice = i;
                    break;
                }
                contador++;
            }
            return indice;
        }
        #endregion
        #region Sobrecargas
        public static bool operator ==(Paleta paleta, Tempera tempera)
        {
            bool retorno = false;

            for (int i = 0; i < paleta._cantMaximaElementos; i++)
            {
                if (paleta._colores.GetValue(i) != null)
                {
                    if (paleta._colores[i] == tempera)
                    {
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }
        public static bool operator !=(Paleta paleta, Tempera tempera)
        {
            return !(paleta == tempera);
        }
        public static Paleta operator +(Paleta paleta, Tempera tempera)
        {
            int indice = -1;
            if (paleta == tempera)
            {
                indice = paleta.ObtenerIndice(tempera);
                paleta._colores[indice] += tempera;
            }
            else
            {
                indice = paleta.ObtenerIndice();
                if (indice > -1)
                {
                    paleta._colores[indice] = tempera;
                }
            }
            return paleta;
        }
        //Clase 08
        public static Paleta operator -(Paleta paleta, Tempera tempera)
        {
            int indice = -1;
            int aux1 = 0, aux2 = 0;
            if (paleta == tempera)
            {
                indice = paleta.ObtenerIndice(tempera);
                aux1 = (sbyte)paleta._colores[indice];
                aux2 = (sbyte)tempera;
                if (aux1 - aux2 <= 0)
                {
                    paleta._colores[indice] = null;
                }
                else
                {
                    paleta._colores[indice] += (sbyte)(aux2 * (-1));
                }
            }
            return paleta;
        }
        #endregion

    }
}

