﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
    class Tinta
    {
        private ConsoleColor _color;
        private ETipoTinta _tinta;
        #region Constructores
        public Tinta()
        {
            this._color = ConsoleColor.Blue;
            this._tinta = ETipoTinta.ConBrillito;
        }
        public Tinta(ConsoleColor color) : this()
        {
            this._color = color;
        }
        public Tinta(ConsoleColor color, ETipoTinta tinta) : this(color)
        {
            this._tinta = tinta;
        }
        #endregion
        #region Metodos
        public static string Mostrar(Tinta tinta)
        {
            return tinta.Mostrar();
        }
        private string Mostrar()
        {
            return this._color.ToString() + "//" + this._tinta.ToString();
        }
        #endregion
        #region Sobrecargas
        public static bool operator == (Tinta t1, Tinta t2)
        {
            return (t1._color == t2._color && t1._tinta == t2._tinta);
        }
        public static bool operator !=(Tinta t1, Tinta t2)
        {
            return !(t1==t2);
        }
        #endregion
    }
}