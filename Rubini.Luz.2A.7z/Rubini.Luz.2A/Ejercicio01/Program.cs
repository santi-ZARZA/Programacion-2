﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercico 01";
            int num = 0, acum = 0, min = 0, max = 0;
            float promedio = 0;

            for(int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese el numero: (Total de numeros {0} de 5): ", i);
                int.TryParse(Console.ReadLine(), out num);
                acum += num;
                if (i == 0)
                {
                    min = num;
                    max = num;
                }
                else
                {
                    if (num < min)
                    {
                        min = num;
                    }
                    else if (num > max)
                    {
                        max = num;
                    }
                }
            }
            promedio = (float)acum / 5;
            Console.WriteLine("Minimo: {0} \nMaximo: {1} \nPromedio: {2}", min, max, promedio);
            Console.ReadKey();
            


        }
    }
}
