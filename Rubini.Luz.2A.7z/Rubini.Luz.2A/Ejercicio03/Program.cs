﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercico 03";
            int num = 0;
            bool flag = false;

            Console.WriteLine("Ingrese numero:");
            int.TryParse(Console.ReadLine(), out num);
            Console.WriteLine("Numeros primos:");
            for (int j = 2; j <= num; j++)
            {
                flag = false;
                for(int i = 1; i <= j; i++)
                {
                    switch(j % i)
                    {
                        case 0:
                            if(i!=1 && i!=j)
                            {
                                flag = true;
                            }
                            break;
                        default:

                            break;
                    }
                }
                if (flag == false)
                {
                    Console.WriteLine("{0}", j);
                }
            }
            Console.ReadKey();
            
        }
    }
}
