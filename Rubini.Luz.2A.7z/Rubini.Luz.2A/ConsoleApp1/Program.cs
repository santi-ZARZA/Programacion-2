﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            static void Main(string[] args)
        {
            try
            {
                N2 num = new N2(2,0);
            }
            catch (MiExcepcion e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadLine();
             * */


            /*
             * public class N2
    {
        public Numero _numero;

        public N2(int x, int y)
        {
            try { this._numero = new Numero(x, y); }
            catch (UnaException e)
            { throw new MiExcepcion(e.Message + "\nMi excepcion", e); }
        }
    }

    public class UnaException : Exception
    {
        public UnaException(string message, Exception inner) : base(message, inner) { }
    }

    public class MiExcepcion : Exception
    {
        public MiExcepcion(string message, Exception inner) : base(message, inner) { }
    }
             * */
        }
    }
}
