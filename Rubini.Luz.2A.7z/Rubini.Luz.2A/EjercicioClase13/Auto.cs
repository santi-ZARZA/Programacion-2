﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase13
{
    public class Auto
    {
        private string _color;
        private string _marca;
        #region Constructores
        public Auto(string color, string marca)
        {
            this._color = color;
            this._marca = marca;
        }
        #endregion
        #region Propiedades
        public string Color
        { get
            {
                return this._color;
            }        
        }
        public string Marca
        {
            get
            {
                return this._marca;
            }
        }
        #endregion
        #region Métodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Marca: {0} -- Color {1}", this.Color, this.Marca);
            return sb.ToString();
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
        #endregion
        #region Sobrecargas
        public static bool operator ==(Auto a1, Auto a2)
        {
            return (a1._color == a2._color && a1._marca == a2._marca);
        }
        public static bool operator !=(Auto a1, Auto a2)
        {
            return !(a1 == a2);
        }
        #endregion
    }
}
