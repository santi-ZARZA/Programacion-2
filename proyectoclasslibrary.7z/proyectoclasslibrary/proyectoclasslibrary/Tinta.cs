﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadLibreria
{
    public class Tinta
    {
        private ConsoleColor colorconsola;
        private ETipotinta tipotinta;



        public Tinta()
        {
            this.colorconsola = ConsoleColor.Black;
            this.tipotinta = ETipotinta.comun;
        }

        public Tinta(ConsoleColor x):this()
        {
            this.colorconsola = x;
        }

        public Tinta(ConsoleColor x, ETipotinta z):this(x)
        {
            this.tipotinta = z;
        }



        private string Mostrar()
        {
            string retorno = this.colorconsola + "-" + this.tipotinta;

            return retorno;
        }

        public static string Mostrar(Tinta x)
        {
            string retorno = "";

            retorno = x.Mostrar();

            return retorno;
        }


        public static bool operator ==(Tinta x1,Tinta x2)
        {
            bool retorno = false;

            if (x1.colorconsola == x2.colorconsola && x1.tipotinta == x2.tipotinta)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Tinta x1, Tinta x2)
        {
            bool retorno = false;

            retorno = !(x1 == x2);

            return retorno;
        }
    }
}
