﻿public enum ETipotinta
{
    comun,
    china,
    yconbrillito,
}