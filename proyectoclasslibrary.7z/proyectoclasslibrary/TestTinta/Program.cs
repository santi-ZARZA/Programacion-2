﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadLibreria;

namespace TestTinta
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta paraImprimir1 = new Tinta();
            Tinta paraImprimir2 = new Tinta(ConsoleColor.Blue);
            //Tinta paraImprimir3 = new Tinta();



            Console.WriteLine(Tinta.Mostrar(paraImprimir1));

            if (paraImprimir1 == paraImprimir1)
            {
                Console.Write("son iguales");
            }
            else
            {
                Console.Write("no son iguales");
            }

            Console.ReadKey();
        }
    }
}
