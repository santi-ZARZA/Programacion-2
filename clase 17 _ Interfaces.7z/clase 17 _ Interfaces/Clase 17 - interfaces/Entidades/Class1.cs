﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public interface IAFIP
    {
        double CalcularImpuesto();
    }


    public static class Gestion
    {
        public static double MostrarImpuestoNacional(IAFIP bienPunible)
        {
            return bienPunible.CalcularImpuesto();
        }
    }


    public abstract class Vehiculo
    {
        protected double _precio;

        public Vehiculo(double precio)
        {
            this._precio = precio;
        }

        public abstract void MostrarPrecio();
    }

    public abstract class Avion : Vehiculo , IAFIP
    {
        protected double _velocidadMaxima;

        public Avion(double precio, double veMax)
            : base(precio)
        {
            this._velocidadMaxima = veMax;
        }

        public double CalcularImpuesto()
        {
            double retorno = base._precio;

            retorno += (retorno * 0.33);

            return retorno;
        }
    }

    public abstract class Auto : Vehiculo
    {
        protected string _patente;

        public Auto(double precio, string patente)
            : base(precio)
        {
            this._patente = patente;
        }

        public abstract void MostrarPatente();
    }

    public class Carreta : Vehiculo
    {
        public Carreta(double precio):base(precio)
        {

        }

        public override void MostrarPrecio()
        {
            throw new NotImplementedException();
        }
    }


    public class Familiar : Auto
    {
        protected int _cantAsientos;

        public Familiar(double precio, string patente, int cantidadAsientos):base(precio,patente)
        {
            this._cantAsientos = cantidadAsientos;
        }

        public override void MostrarPatente()
        {
            Console.WriteLine(this._patente);
        }
    }

    public class Deportivo : Auto , IAFIP
    {
        protected int _caballosFuerza;

        public Deportivo(double precio, string patente, int caballosdefuerza)
            : base(precio, patente)
        {
            this._caballosFuerza = caballosdefuerza;
        }

        public double CalcularImpuesto()
        {
            double retorno = base._precio;

            retorno += (retorno * 0.28);

            return retorno;
        }

    }// falta


    public class Privado : Avion
    {
        protected int _valoracionServicioDeAbordo;

        public Privado(double precio, double velocidad, int valoracion)
            : base(precio,velocidad)
        {
            this._valoracionServicioDeAbordo = valoracion;
        }
            
    }

    public class Comercial : Avion
    {
        protected int _capacidadPasajeros;

        public Comercial(double precio, double velocidad, int pasajeros)
            : base(precio, velocidad)
        {
            this._capacidadPasajeros = pasajeros;
        }
    }




}
